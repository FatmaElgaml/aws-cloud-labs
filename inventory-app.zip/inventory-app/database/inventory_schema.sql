-- =====================================================================
--  Inventory Management System - Database Schema + Sample Data
--  Target : MySQL 8.4 LTS (recommended) or 8.0 - Amazon RDS for MySQL
--
--  How to load it (from the EC2 instance, after installing a MySQL client):
--      mysql -h <RDS-ENDPOINT> -P 3306 -u admin -p < inventory_schema.sql
--
--  WARNING: this script DROPS and re-creates the tables, so running it
--  again resets the database back to the sample data.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS inventory_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE inventory_db;

-- Drop in reverse dependency order (children first)
DROP VIEW  IF EXISTS v_low_stock_products;
DROP TABLE IF EXISTS stock_movements;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- ---------------------------------------------------------------------
-- categories : groups of products (Electronics, Office Supplies, ...)
-- ---------------------------------------------------------------------
CREATE TABLE categories (
    category_id   INT           NOT NULL AUTO_INCREMENT,
    name          VARCHAR(100)  NOT NULL,
    description   VARCHAR(255)  NULL,
    created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (category_id),
    CONSTRAINT uq_categories_name UNIQUE (name)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- suppliers : companies we buy products from
-- ---------------------------------------------------------------------
CREATE TABLE suppliers (
    supplier_id   INT           NOT NULL AUTO_INCREMENT,
    name          VARCHAR(150)  NOT NULL,
    contact_name  VARCHAR(100)  NULL,
    email         VARCHAR(150)  NULL,
    phone         VARCHAR(30)   NULL,
    created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (supplier_id),
    CONSTRAINT uq_suppliers_name UNIQUE (name)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- products : the items we keep in stock
--   quantity_in_stock is only changed through stock_movements
--   (the application never lets you type a quantity directly).
-- ---------------------------------------------------------------------
CREATE TABLE products (
    product_id         INT            NOT NULL AUTO_INCREMENT,
    sku                VARCHAR(50)    NOT NULL,
    name               VARCHAR(150)   NOT NULL,
    description        VARCHAR(500)   NULL,
    category_id        INT            NOT NULL,
    supplier_id        INT            NULL,
    unit_price         DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    quantity_in_stock  INT            NOT NULL DEFAULT 0,
    reorder_level      INT            NOT NULL DEFAULT 10,
    created_at         DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (product_id),
    CONSTRAINT uq_products_sku UNIQUE (sku),
    INDEX ix_products_category (category_id),
    INDEX ix_products_supplier (supplier_id),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id)
        REFERENCES categories (category_id) ON DELETE RESTRICT,
    CONSTRAINT fk_products_supplier FOREIGN KEY (supplier_id)
        REFERENCES suppliers (supplier_id) ON DELETE SET NULL,
    CONSTRAINT ck_products_price    CHECK (unit_price >= 0),
    CONSTRAINT ck_products_qty      CHECK (quantity_in_stock >= 0),
    CONSTRAINT ck_products_reorder  CHECK (reorder_level >= 0)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- stock_movements : history of every stock change
--   IN     = goods received        (quantity_change > 0)
--   OUT    = goods issued / sold   (quantity_change < 0)
--   ADJUST = stock-count correction (either sign)
--   SUM(quantity_change) per product always equals quantity_in_stock.
-- ---------------------------------------------------------------------
CREATE TABLE stock_movements (
    movement_id      INT                         NOT NULL AUTO_INCREMENT,
    product_id       INT                         NOT NULL,
    movement_type    ENUM('IN','OUT','ADJUST')   NOT NULL,
    quantity_change  INT                         NOT NULL,
    note             VARCHAR(255)                NULL,
    movement_date    DATETIME                    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (movement_id),
    INDEX ix_movements_product_date (product_id, movement_date),
    CONSTRAINT fk_movements_product FOREIGN KEY (product_id)
        REFERENCES products (product_id) ON DELETE CASCADE
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- users : accounts that can log in to the application
--   role Admin  = full access (create, edit, delete, record stock)
--   role Viewer = read-only
--   password_hash is a salted PBKDF2 hash (ASP.NET Core PasswordHasher),
--   never the plain password.
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id        INT                      NOT NULL AUTO_INCREMENT,
    username       VARCHAR(50)              NOT NULL,
    password_hash  VARCHAR(255)             NOT NULL,
    full_name      VARCHAR(100)             NOT NULL,
    role           ENUM('Admin','Viewer')   NOT NULL DEFAULT 'Viewer',
    is_active      TINYINT(1)               NOT NULL DEFAULT 1,
    last_login_at  DATETIME                 NULL,
    created_at     DATETIME                 NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    CONSTRAINT uq_users_username UNIQUE (username)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- View: products at or below their reorder level
-- ---------------------------------------------------------------------
CREATE VIEW v_low_stock_products AS
SELECT p.product_id,
       p.sku,
       p.name,
       c.name                                AS category,
       s.name                                AS supplier,
       p.quantity_in_stock,
       p.reorder_level,
       p.reorder_level - p.quantity_in_stock AS shortage
FROM products p
JOIN categories c     ON c.category_id = p.category_id
LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
WHERE p.quantity_in_stock <= p.reorder_level;


-- =====================================================================
--  SAMPLE DATA
-- =====================================================================

-- Demo login accounts (CHANGE THESE PASSWORDS in a real deployment):
--   admin  / Admin@123   -> Admin  (full access)
--   viewer / Viewer@123  -> Viewer (read-only)
INSERT INTO users (username, password_hash, full_name, role) VALUES
 ('admin',  'AQAAAAIAAYagAAAAEDYLfWHTkV3f8GYFTd325EQYXo9/4WUAk2zkRQcwyLGcIBs34F1gPQ1hp+UYcu8J5Q==', 'Inventory Administrator', 'Admin'),
 ('viewer', 'AQAAAAIAAYagAAAAENy5yRFLoS3m0ILl2cSYNSAfKQaIfpb5vzMn6seMXvCnZ/c4J/h07ydrnecidZHl7A==', 'Read-only Viewer',        'Viewer');

INSERT INTO categories (category_id, name, description) VALUES
 (1, 'Electronics',      'Computers, peripherals and accessories'),
 (2, 'Office Supplies',  'Paper, pens and everyday office items'),
 (3, 'Furniture',        'Desks, chairs and storage'),
 (4, 'Networking',       'Switches, routers, cables'),
 (5, 'Cleaning',         'Cleaning and hygiene products');

INSERT INTO suppliers (supplier_id, name, contact_name, email, phone) VALUES
 (1, 'TechSource Distribution', 'Sara Adel',     'sales@techsource.example',  '+20 2 2345 6789'),
 (2, 'Nile Office Trading',     'Karim Hassan',  'orders@nileoffice.example', '+20 2 3456 7890'),
 (3, 'Delta Furniture Co.',     'Mona Farouk',   'info@deltafurniture.example','+20 3 4567 8901'),
 (4, 'CleanPro Supplies',       'Omar Nabil',    'contact@cleanpro.example',  '+20 2 5678 9012');

-- Products start at 0; the real quantity is calculated from the movements below
INSERT INTO products (product_id, sku, name, description, category_id, supplier_id, unit_price, reorder_level) VALUES
 ( 1, 'ELEC-001', 'Laptop 14" Core i5',          '16 GB RAM, 512 GB SSD',            1, 1, 18500.00,  5),
 ( 2, 'ELEC-002', 'Wireless Mouse',              '2.4 GHz, USB receiver',            1, 1,   350.00, 20),
 ( 3, 'ELEC-003', 'USB-C Docking Station',       'HDMI x2, Ethernet, USB 3.0',       1, 1,  2900.00,  5),
 ( 4, 'ELEC-004', '24" LED Monitor',             'Full HD, IPS panel',               1, 1,  4800.00,  8),
 ( 5, 'OFF-001',  'A4 Copy Paper (box of 5)',    '80 gsm, 500 sheets per ream',      2, 2,   950.00, 30),
 ( 6, 'OFF-002',  'Ballpoint Pens (pack of 50)', 'Blue ink',                         2, 2,   175.00, 15),
 ( 7, 'OFF-003',  'Stapler Heavy Duty',          'Up to 100 sheets',                 2, 2,   420.00, 10),
 ( 8, 'OFF-004',  'Whiteboard Markers (4 pack)', 'Assorted colours',                 2, 2,    95.00, 25),
 ( 9, 'FUR-001',  'Ergonomic Office Chair',      'Adjustable lumbar support',        3, 3,  6200.00,  4),
 (10, 'FUR-002',  'Standing Desk 140cm',         'Electric height adjustment',       3, 3, 14500.00,  2),
 (11, 'FUR-003',  'Filing Cabinet 3-Drawer',     'Lockable, steel',                  3, 3,  3700.00,  3),
 (12, 'NET-001',  '24-Port Gigabit Switch',      'Managed, rack-mountable',          4, 1,  7800.00,  3),
 (13, 'NET-002',  'Cat6 Patch Cable 2m',         'Snagless, blue',                   4, 1,    60.00, 50),
 (14, 'CLN-001',  'Hand Sanitizer 500ml',        '70% alcohol',                      5, 4,    85.00, 40),
 (15, 'CLN-002',  'Microfiber Cloths (10 pack)', 'Lint-free',                        5, 4,   140.00, 20);

INSERT INTO stock_movements (product_id, movement_type, quantity_change, note, movement_date) VALUES
 ( 1, 'IN',      20, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 2, 'IN',     120, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 3, 'IN',      15, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 4, 'IN',      25, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 5, 'IN',     200, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 6, 'IN',      60, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 7, 'IN',      30, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 8, 'IN',      80, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 9, 'IN',      12, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (10, 'IN',       6, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (11, 'IN',       8, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (12, 'IN',      10, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (13, 'IN',     300, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (14, 'IN',     150, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 (15, 'IN',      40, 'Initial stock',                 NOW() - INTERVAL 30 DAY),
 ( 1, 'OUT',    -16, 'Issued to new hires - batch 1', NOW() - INTERVAL 20 DAY),
 ( 2, 'OUT',    -45, 'Issued to IT department',       NOW() - INTERVAL 18 DAY),
 ( 5, 'OUT',   -185, 'Monthly office distribution',   NOW() - INTERVAL 15 DAY),
 ( 9, 'OUT',     -9, 'Finance floor refurbishment',   NOW() - INTERVAL 12 DAY),
 (13, 'OUT',   -120, 'Server room cabling',           NOW() - INTERVAL 10 DAY),
 (14, 'OUT',   -125, 'Distributed to all floors',     NOW() - INTERVAL  8 DAY),
 ( 4, 'IN',      10, 'PO-2024-117 received',          NOW() - INTERVAL  6 DAY),
 ( 8, 'ADJUST',  -3, 'Stock count: 3 dried out',      NOW() - INTERVAL  5 DAY),
 (12, 'OUT',     -8, 'New branch network setup',      NOW() - INTERVAL  3 DAY),
 ( 6, 'OUT',    -50, 'Training center supplies',      NOW() - INTERVAL  2 DAY),
 ( 3, 'OUT',     -4, 'Issued to managers',            NOW() - INTERVAL  1 DAY);

-- Make quantity_in_stock match the movement history
UPDATE products p
SET p.quantity_in_stock = (
    SELECT COALESCE(SUM(m.quantity_change), 0)
    FROM stock_movements m
    WHERE m.product_id = p.product_id
);


-- =====================================================================
--  OPTIONAL (recommended exercise): create a dedicated application user
--  instead of connecting the app with the RDS master "admin" account.
--  Uncomment, choose a strong password, run it, then put this user in
--  the application's appsettings.json.
-- =====================================================================
-- CREATE USER 'inventory_app'@'%' IDENTIFIED BY 'Change_Me_Str0ng!';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON inventory_db.* TO 'inventory_app'@'%';
-- FLUSH PRIVILEGES;


-- Quick check
SELECT 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION ALL SELECT 'categories',      COUNT(*) FROM categories
UNION ALL SELECT 'suppliers',       COUNT(*) FROM suppliers
UNION ALL SELECT 'products',        COUNT(*) FROM products
UNION ALL SELECT 'stock_movements', COUNT(*) FROM stock_movements;
